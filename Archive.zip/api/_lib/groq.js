const MODEL_CONFIG = {
  vision: { primary: "qwen/qwen3.6-27b", fallback: "qwen/qwen3.6-27b" },
  reasoning: { primary: "openai/gpt-oss-120b", fallback: "openai/gpt-oss-20b" },
  light: { primary: "openai/gpt-oss-20b", fallback: "openai/gpt-oss-120b" },
};
const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";

// Rough token estimate: ~4 chars per token for English text
function estimateTokens(str = "") {
  return Math.ceil(str.length / 4);
}

function truncateToTokenBudget(str, maxTokens) {
  const maxChars = Math.max(maxTokens, 0) * 4;
  if (!str || str.length <= maxChars) return str;
  return str.slice(str.length - maxChars); // keep the tail
}

export async function callGroq({
  task = "reasoning",
  systemInstruction,
  prompt,
  content,
  maxTokens = 2048,
  totalTokenBudget = 7800, // stay just under the 8000 TPM org cap, with a little margin
}) {
  const models = MODEL_CONFIG[task] || MODEL_CONFIG.reasoning;
  if (!process.env.GROQ_API_KEY) {
    throw new Error(
      "GROQ_API_KEY is not set. Add it to your environment (Vercel env vars, or .env for local dev)."
    );
  }

  // IMPORTANT: Groq's TPM counts prompt tokens + reserved max_tokens (completion budget)
  // together. So the input budget must leave room for maxTokens too.
  const systemTokens = estimateTokens(systemInstruction || "");
  const inputBudget = Math.max(totalTokenBudget - maxTokens - systemTokens, 300);

  function buildMessages() {
    let userContent = truncateToTokenBudget(content || prompt || "", inputBudget);
    const messages = [];
    if (systemInstruction) messages.push({ role: "system", content: systemInstruction });
    messages.push({ role: "user", content: userContent });
    return messages;
  }

  async function attempt(model) {
    return fetch(GROQ_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model,
        messages: buildMessages(),
        response_format: { type: "json_object" },
        temperature: 0.6,
        max_tokens: maxTokens,
      }),
    });
  }

  let res = await attempt(models.primary);

  // Retry on rate limit (429), request-too-large (413), or server errors (5xx)
  const shouldFallback =
    (res.status === 429 || res.status === 413 || res.status >= 500) &&
    models.fallback !== models.primary;

  if (shouldFallback) {
    console.error(`[groq] ${models.primary} failed (${res.status}), retrying on ${models.fallback}`);
    res = await attempt(models.fallback);
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Groq error ${res.status}: ${errText}`);
  }

  const data = await res.json();
  console.log("[groq] usage:", data.usage);
  const text = data.choices?.[0]?.message?.content;
  if (!text) throw new Error("Empty Groq response");

  try {
    return JSON.parse(text);
  } catch {
    throw new Error("Groq returned malformed JSON");
  }
}