import { useState } from "react";
import { Copy, Check, ThumbsUp, ThumbsDown, Share2, RotateCw, MoreHorizontal, ArrowRight } from "lucide-react";

export default function ChatMessage({ message, onStartSurvey }) {
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    navigator.clipboard?.writeText(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (message.role === "user") {
    return (
      <div className="flex justify-end animate-fadeInUp">
        <div className="bg-panel2 rounded-2xl px-4 py-2.5 max-w-[80%] text-sm">{message.text}</div>
      </div>
    );
  }

  return (
    <div className="max-w-[85%] animate-fadeInUp">
      <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{message.text}</p>

      {message.suggestSurvey && (
        <button
          onClick={() => onStartSurvey(message.id)}
          className="focus-ring mt-3 inline-flex items-center gap-1.5 font-semibold text-sm hover:gap-2.5 transition-all"
        >
          Start Survey
          <ArrowRight size={15} />
        </button>
      )}

      <div className="flex items-center gap-3 mt-2.5 text-ink/35">
        <button onClick={handleCopy} className="focus-ring hover:text-ink transition" title={copied ? "Copied" : "Copy"}>
          {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
        </button>
        <button className="focus-ring hover:text-ink transition" title="Good response"><ThumbsUp size={14} /></button>
        <button className="focus-ring hover:text-ink transition" title="Bad response"><ThumbsDown size={14} /></button>
        <button className="focus-ring hover:text-ink transition" title="Share"><Share2 size={14} /></button>
        <button className="focus-ring hover:text-ink transition" title="Regenerate"><RotateCw size={14} /></button>
        <button className="focus-ring hover:text-ink transition" title="More"><MoreHorizontal size={14} /></button>
      </div>
    </div>
  );
}
