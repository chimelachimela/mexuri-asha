import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Plus, SendHorizontal, SquarePen, FileText, X, Loader2 } from "lucide-react";
import { useApp } from "../context/AppContext";
import Sidebar from "../components/Sidebar";
import ChatMessage from "../components/ChatMessage";
import SurveyBuildPanel from "../components/SurveyBuildPanel";
import * as db from "../lib/services/dbService";
import * as ai from "../lib/services/aiService";

export default function Chat() {
  const { session, chats, addChatToList, upsertChatMeta, removeChatFromList } = useApp();
  const { chatId } = useParams();
  const navigate = useNavigate();

  const [activeChat, setActiveChat] = useState(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const [mySurveys, setMySurveys] = useState([]);
  const [refPickerOpen, setRefPickerOpen] = useState(false);
  const [referencedSurvey, setReferencedSurvey] = useState(null);
  const [referenceLoading, setReferenceLoading] = useState(false);

  const [planningQuestions, setPlanningQuestions] = useState(null); // array | null
  const [planningIndex, setPlanningIndex] = useState(0);
  const [planningAnswers, setPlanningAnswers] = useState({});
  const [buildPanel, setBuildPanel] = useState(null); // { building, survey } | null

  const scrollRef = useRef(null);

  useEffect(() => {
    if (session?.id) db.listSurveys(session.id).then(setMySurveys);
  }, [session?.id]);

  useEffect(() => {
    if (!chatId) { setActiveChat(null); return; }
    let active = true;
    db.getChat(chatId)
      .then((c) => {
        if (!active) return;
        if (!c) { navigate("/chat", { replace: true }); return; } // chat doesn't exist/was deleted
        setActiveChat(c);
      })
      .catch((err) => active && setErrorMsg(err.message || "Couldn't load that chat."));
    return () => { active = false; };
  }, [chatId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [activeChat?.messages?.length]);

  function handleNewChat() {
    navigate("/chat");
    setInput("");
    setReferencedSurvey(null);
    setPlanningQuestions(null);
  }

  function handleSelectChat(id) {
    navigate(`/chat/${id}`);
  }

  function toggleRefPicker() {
    setRefPickerOpen((o) => !o);
  }

  async function pickReference(survey) {
    setRefPickerOpen(false);
    // The sidebar list (mySurveys) doesn't include response rows — fetch the
    // full survey so the AI has real response data to analyze, not just the
    // question list.
    setReferencedSurvey(survey);
    setReferenceLoading(true);
    try {
      const full = await db.getSurvey(survey.id);
      if (full) setReferencedSurvey(full);
    } catch (err) {
      console.error(err);
      // Keep the lightweight version already set — reference still works,
      // it just won't have response data to analyze.
    } finally {
      setReferenceLoading(false);
    }
  }

  function clearReference() {
    setReferencedSurvey(null);
  }

  async function handleSend() {
    const text = input.trim();
    if (!text || sending) return;
    setInput("");
    setErrorMsg("");
    setSending(true);

    try {
      let chat = activeChat;
      if (!chat) {
        chat = await db.createChat(session.id);
        setActiveChat(chat);
        addChatToList(chat);
        navigate(`/chat/${chat.id}`, { replace: true });
      }

      const userMsg = await db.appendMessage(chat.id, { role: "user", text });
      chat = { ...chat, messages: [...chat.messages, userMsg] };
      setActiveChat(chat);

      // Title generation and the AI reply are independent — run them
      // together instead of waiting on one before starting the other.
      const titlePromise = !chat.titleLocked ? ai.generateChatTitle(text) : Promise.resolve(null);
      const replyPromise = ai.sendMessage({
        history: chat.messages,
        userMessage: text,
        responseStyle: session.responseStyle,
        referencedSurvey: referencedSurvey
          ? { title: referencedSurvey.title, description: referencedSurvey.description, questions: referencedSurvey.questions }
          : null,
      });

      const [title, reply] = await Promise.all([titlePromise, replyPromise]);
      setReferencedSurvey(null);

      if (title) {
        await db.updateChat(chat.id, { title, titleLocked: true });
        chat = { ...chat, title, titleLocked: true };
        upsertChatMeta(chat.id, { title, titleLocked: true });
      }

      const assistantMsg = await db.appendMessage(chat.id, {
        role: "assistant",
        text: reply.text,
        suggestSurvey: reply.suggestSurvey,
      });
      chat = { ...chat, messages: [...chat.messages, assistantMsg] };
      setActiveChat(chat);
      upsertChatMeta(chat.id, { title: chat.title });
    } catch (err) {
      console.error(err);
      setErrorMsg(err.message || "Something went wrong reaching Asha. Please try again.");
    } finally {
      setSending(false);
    }
  }

  function conversationTranscript() {
    return (activeChat?.messages || []).map((m) => `${m.role}: ${m.text}`).join("\n");
  }

  async function handleStartSurvey() {
    try {
      const questions = await ai.generatePlanningQuestions(conversationTranscript());
      setPlanningQuestions(questions);
      setPlanningIndex(0);
      setPlanningAnswers({});
    } catch (err) {
      console.error(err);
      setErrorMsg(err.message || "Couldn't start survey planning. Please try again.");
    }
  }

  async function handlePlanningComplete(answers) {
    setPlanningQuestions(null);
    setBuildPanel({ building: true, survey: null });
    setErrorMsg("");

    try {
      const planningQA = (planningQuestions || [])
        .map((q) => `Q: ${q.text}\nA: ${answers[q.id] || "(skipped)"}`)
        .join("\n\n");

      const chatContext = [
        "Conversation with the founder:",
        conversationTranscript(),
        "",
        "Planning answers the founder just gave:",
        planningQA,
      ].join("\n");

      const drafted = await ai.generateSurvey({ chatContext });
      const survey = await db.createSurvey(session.id, drafted);
      await db.updateChat(activeChat.id, { surveyDraftId: survey.id });
      setBuildPanel({ building: false, survey });
      setMySurveys((prev) => [survey, ...prev]);
    } catch (err) {
      console.error(err);
      setErrorMsg(err.message || "Couldn't build the survey. Please try again.");
      setBuildPanel(null);
    }
  }

  async function handleDeleteChat(id) {
    await db.deleteChat(id);
    if (activeChat?.id === id) navigate("/chat");
    removeChatFromList(id);
  }

  return (
    <div className="h-screen w-full bg-canvas flex overflow-hidden">
      <Sidebar
        activeChat={activeChat?.id}
        onSelectChat={handleSelectChat}
        onNewChat={handleNewChat}
        onDeleteChat={handleDeleteChat}
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((c) => !c)}
      />

      <div className="flex-1 min-w-0 flex">
        <div className="flex-1 min-w-0 flex flex-col relative">
          {/* header */}
          <div className="flex items-center justify-between pl-16 pr-6 py-4 md:px-6 shrink-0">
            <button className="focus-ring flex items-center gap-1.5 text-sm text-ink/70 bg-panel border border-line rounded-lg px-3 py-1.5 hover:border-line2 transition">
              Free
            </button>
            <button
              onClick={handleNewChat}
              title="New chat"
              className="focus-ring w-8 h-8 rounded-lg flex items-center justify-center text-ink/60 hover:text-ink hover:bg-panel transition"
            >
              <SquarePen size={17} />
            </button>
          </div>

          {errorMsg && (
            <div className="mx-6 mb-2 flex items-center justify-between gap-3 bg-red-500/10 border border-red-500/30 text-red-400 text-sm rounded-lg px-3.5 py-2.5">
              <span>{errorMsg}</span>
              <button onClick={() => setErrorMsg("")} className="focus-ring text-red-400/70 hover:text-red-400 shrink-0">
                <X size={14} />
              </button>
            </div>
          )}

          {/* messages / empty state */}
          {!activeChat || activeChat.messages.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center px-6">
              <h1 className="text-2xl sm:text-3xl font-bold text-center mb-8 max-w-md">
                {session?.name ? `${session.name}, ` : ""}what problem are we solving?
              </h1>
              <div className="w-full max-w-xl">
                <Composer
                  input={input}
                  setInput={setInput}
                  onSend={handleSend}
                  sending={sending}
                  centered
                  mySurveys={mySurveys}
                  referencedSurvey={referencedSurvey}
                  referenceLoading={referenceLoading}
                  onPickReference={pickReference}
                  onClearReference={clearReference}
                  refPickerOpen={refPickerOpen}
                  onToggleRefPicker={toggleRefPicker}
                />
              </div>
            </div>
          ) : (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
                <div className="max-w-2xl mx-auto space-y-6">
                  {activeChat.messages.map((m) => (
                    <ChatMessage key={m.id} message={m} onStartSurvey={handleStartSurvey} />
                  ))}
                  {sending && (
                    <div className="flex items-center gap-1.5 text-ink/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulseSoft" />
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulseSoft [animation-delay:150ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulseSoft [animation-delay:300ms]" />
                    </div>
                  )}
                </div>
              </div>
              <div className="px-6 pb-6 shrink-0">
                <div className="max-w-2xl mx-auto">
                  {planningQuestions ? (
                    <PlanningComposer
                      questions={planningQuestions}
                      index={planningIndex}
                      setIndex={setPlanningIndex}
                      answers={planningAnswers}
                      setAnswers={setPlanningAnswers}
                      onComplete={handlePlanningComplete}
                      onCancel={() => setPlanningQuestions(null)}
                    />
                  ) : (
                    <Composer
                      input={input}
                      setInput={setInput}
                      onSend={handleSend}
                      sending={sending}
                      mySurveys={mySurveys}
                      referencedSurvey={referencedSurvey}
                      referenceLoading={referenceLoading}
                      onPickReference={pickReference}
                      onClearReference={clearReference}
                      refPickerOpen={refPickerOpen}
                      onToggleRefPicker={toggleRefPicker}
                    />
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {buildPanel && (
          <SurveyBuildPanel
            survey={buildPanel.survey}
            building={buildPanel.building}
            onClose={() => setBuildPanel(null)}
          />
        )}
      </div>
    </div>
  );
}

function Composer({
  input,
  setInput,
  onSend,
  sending,
  centered,
  mySurveys,
  referencedSurvey,
  referenceLoading,
  onPickReference,
  onClearReference,
  refPickerOpen,
  onToggleRefPicker,
}) {
  const textareaRef = useRef(null);

  // Refocus once a send finishes — covers both "clicked the send button"
  // (which naturally steals focus) and the very first message, where the
  // composer remounts moving from the centered empty state to the docked one.
  useEffect(() => {
    if (!sending) textareaRef.current?.focus();
  }, [sending]);

  return (
    <div className={`bg-panel border border-line rounded-2xl p-3 ${centered ? "shadow-modal" : ""}`}>
      {referencedSurvey && (
        <div className="flex items-center gap-2 mb-2 bg-panel2 border border-line rounded-lg px-2.5 py-1.5 w-fit">
          {referenceLoading ? (
            <Loader2 size={12} className="text-ink/40 shrink-0 animate-spin" />
          ) : (
            <FileText size={12} className="text-ink/40 shrink-0" />
          )}
          <span className="text-xs text-ink/70 truncate max-w-[180px]">{referencedSurvey.title}</span>
          <button onClick={onClearReference} className="focus-ring text-ink/30 hover:text-ink shrink-0">
            <X size={11} />
          </button>
        </div>
      )}
      <textarea
        ref={textareaRef}
        autoFocus
        rows={1}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            onSend();
          }
        }}
        placeholder="Ask Asha…"
        className="w-full bg-transparent resize-none text-sm placeholder:text-ink/30 px-1 py-1 max-h-40 outline-none focus:ring-0"
      />
      <div className="flex items-center justify-between mt-2 relative">
        <button
          onClick={onToggleRefPicker}
          title="Reference a survey"
          className="focus-ring w-8 h-8 rounded-lg flex items-center justify-center text-ink/50 hover:text-ink hover:bg-panel2 transition"
        >
          <Plus size={17} />
        </button>

        {refPickerOpen && (
          <div className="absolute bottom-11 left-0 w-64 max-h-56 overflow-y-auto bg-panel border border-line rounded-xl shadow-modal py-1 z-10">
            {mySurveys.length === 0 && (
              <div className="text-xs text-ink/30 px-3 py-2.5">No surveys yet</div>
            )}
            {mySurveys.map((s) => (
              <button
                key={s.id}
                onClick={() => onPickReference(s)}
                className="focus-ring w-full text-left px-3 py-2 text-xs text-ink/70 hover:bg-panel2 hover:text-ink transition truncate"
              >
                {s.title}
              </button>
            ))}
          </div>
        )}

        <button
          onClick={onSend}
          disabled={!input.trim() || sending}
          className="focus-ring w-8 h-8 rounded-full bg-accent flex items-center justify-center disabled:opacity-40 transition hover:bg-accent-soft"
        >
          <SendHorizontal size={15} />
        </button>
      </div>
    </div>
  );
}

// Inline replacement for the composer while planning questions are being
// asked — same information as the old fullscreen modal, just docked in
// place instead of interrupting the chat.
function PlanningComposer({ questions, index, setIndex, answers, setAnswers, onComplete, onCancel }) {
  const q = questions[index];
  const selected = answers[q.id];
  const isLast = index === questions.length - 1;

  function selectOption(opt) {
    setAnswers((a) => ({ ...a, [q.id]: opt }));
  }

  function handleNext() {
    if (!selected) return;
    if (isLast) onComplete(answers);
    else setIndex(index + 1);
  }

  return (
    <div className="bg-panel border border-line rounded-2xl p-4 shadow-modal">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] text-ink/40">
          Question {index + 1} of {questions.length}
        </span>
        <button onClick={onCancel} className="focus-ring text-ink/40 hover:text-ink text-xs">
          Cancel
        </button>
      </div>
      <div className="h-1 bg-line rounded-full overflow-hidden mb-3">
        <div
          className="h-full bg-gradient-to-r from-accent-from to-accent-to transition-all duration-300"
          style={{ width: `${((index + 1) / questions.length) * 100}%` }}
        />
      </div>
      <p className="text-sm font-medium mb-3">{q.text}</p>
      <div className="flex flex-wrap gap-2 mb-3">
        {q.options.map((opt) => (
          <button
            key={opt}
            onClick={() => selectOption(opt)}
            className={`focus-ring text-xs px-3 py-2 rounded-full border transition ${selected === opt
                ? "border-accent-soft bg-accent-soft/10 text-ink"
                : "border-line2 text-ink/60 hover:border-ink/30 hover:text-ink"
              }`}
          >
            {opt}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-between">
        <button
          onClick={() => setIndex((i) => Math.max(0, i - 1))}
          disabled={index === 0}
          className="focus-ring text-xs text-ink/40 hover:text-ink disabled:opacity-30"
        >
          Back
        </button>
        <button
          onClick={handleNext}
          disabled={!selected}
          className="focus-ring bg-btn text-btn-foreground disabled:opacity-30 font-medium text-xs px-4 py-2 rounded-lg hover:bg-btn/90 transition"
        >
          {isLast ? "Build survey" : "Next"}
        </button>
      </div>
    </div>
  );
}