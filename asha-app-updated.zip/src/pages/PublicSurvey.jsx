import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import * as db from "../lib/services/dbService";
import { SurveyForm, SurveyFormChrome, SurveyThanksScreen } from "../components/SurveyForm";

export default function PublicSurvey() {
    const { slug } = useParams();
    const [survey, setSurvey] = useState(undefined); // undefined = loading, null = not found
    const [answers, setAnswers] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    useEffect(() => {
        db.getSurveyBySlug(slug).then((s) => setSurvey(s && s.status === "published" ? s : null));
    }, [slug]);

    function setAnswer(questionId, value) {
        setAnswers((prev) => ({ ...prev, [questionId]: value }));
    }

    function toggleMulti(questionId, option) {
        setAnswers((prev) => {
            const current = prev[questionId] || [];
            const next = current.includes(option)
                ? current.filter((o) => o !== option)
                : [...current, option];
            return { ...prev, [questionId]: next };
        });
    }

    const allAnswered =
        survey?.questions.every((q) => {
            const a = answers[q.id];
            return q.type === "multi" ? a && a.length > 0 : !!a;
        }) ?? false;

    async function handleSubmit() {
        if (!allAnswered || submitting) return;
        setSubmitting(true);
        try {
            await db.submitResponse(survey.id, answers);
            setSubmitted(true);
        } catch (err) {
            console.error(err);
            setSubmitting(false);
        }
    }

    if (survey === undefined) {
        return (
            <div className="min-h-screen bg-canvas flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-ink/20 border-t-ink/70 rounded-full animate-spin" />
            </div>
        );
    }

    if (survey === null) {
        return (
            <div className="min-h-screen bg-canvas flex items-center justify-center px-6">
                <div className="text-center max-w-sm">
                    <h1 className="text-xl font-bold mb-2">Survey not found</h1>
                    <p className="text-ink/40 text-sm">
                        This link may be wrong, or the survey isn't published anymore.
                    </p>
                </div>
            </div>
        );
    }

    if (submitted) {
        return (
            <div className="min-h-screen bg-canvas">
                <SurveyThanksScreen />
            </div>
        );
    }

    const answeredCount = survey.questions.filter((q) => {
        const a = answers[q.id];
        return q.type === "multi" ? a && a.length > 0 : !!a;
    }).length;

    return (
        <div className="min-h-screen bg-canvas pb-32">
            <SurveyFormChrome survey={survey} answeredCount={answeredCount}>
                <SurveyForm survey={survey} answers={answers} setAnswer={setAnswer} toggleMulti={toggleMulti} />
            </SurveyFormChrome>

            {/* sticky submit bar */}
            <div className="fixed bottom-0 left-0 right-0 bg-canvas/90 backdrop-blur-sm border-t border-line px-6 py-4">
                <div className="max-w-xl mx-auto flex items-center justify-between">
                    <span className="text-xs text-ink/40">
                        {answeredCount} of {survey.questions.length} answered
                    </span>
                    <button
                        onClick={handleSubmit}
                        disabled={!allAnswered || submitting}
                        className="focus-ring bg-btn text-btn-foreground font-medium text-sm rounded-lg px-5 py-2.5 disabled:opacity-40 hover:bg-btn/90 transition"
                    >
                        {submitting ? "Submitting…" : "Submit"}
                    </button>
                </div>
            </div>
        </div>
    );
}
